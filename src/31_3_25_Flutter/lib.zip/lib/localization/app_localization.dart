import 'package:flutter/material.dart';

class AppLocalization {
  final BuildContext? context;

  AppLocalization(this.context);

  static AppLocalization of(BuildContext context) {
    return AppLocalization(context);
  }

  String translate(String key) {
    final translations = {
      'en': {
        'Tuition Management': 'Tuition Management',
        'Welcome to Tuition Management': 'Welcome to Tuition Management',
        'Go': 'Go',
        'Pay Tuition': 'Pay Tuition',
        'Payment': 'Payment',
        'Pay': 'Pay',
        'for': 'for',
        'Confirm Payment': 'Confirm Payment',
      },
      'es': {
        'Tuition Management': 'Gestión de Matrículas',
        'Welcome to Tuition Management': 'Bienvenido a la Gestión de Matrículas',
        'Go': 'Ir',
        'Pay Tuition': 'Pagar Matrícula',
        'Payment': 'Pago',
        'Pay': 'Pagar',
        'for': 'para',
        'Confirm Payment': 'Confirmar Pago',
      },
      'ta': {
        'Tuition Management': 'கல்வி மேலாண்மை',
        'Welcome to Tuition Management': 'கல்வி மேலாண்மைக்கு வரவேற்கிறோம்',
        'Go': 'செல்',
        'Pay Tuition': 'கட்டணம் செலுத்தவும்',
        'Payment': 'கட்டணம்',
        'Pay': 'செலுத்தவும்',
        'for': 'க்கு',
        'Confirm Payment': 'கட்டணத்தை உறுதிப்படுத்தவும்',
      },
    };

    String languageCode = Localizations.localeOf(context!).languageCode;
    return translations[languageCode]?[key] ?? key;
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<AppLocalization> {
  @override
  bool isSupported(Locale locale) => ['en', 'es', 'ta'].contains(locale.languageCode);

  @override
  Future<AppLocalization> load(Locale locale) async {
    return AppLocalization(null); // Pass the correct context or handle localization differently
  }

  @override
  bool shouldReload(covariant LocalizationsDelegate<AppLocalization> old) => false;
}