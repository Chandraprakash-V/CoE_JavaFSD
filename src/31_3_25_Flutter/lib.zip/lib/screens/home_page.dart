import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import '../models/course.dart';
import '../localization/app_localization.dart';
import 'course_detail_page.dart';

// Home Page with Navigation
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Course> _courses = [];
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _tuitionFeeController = TextEditingController();
  bool _isFirebaseInitialized = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    initializeFirebase();
  }

  Future<void> initializeFirebase() async {
    try {
      await Firebase.initializeApp();
      setState(() {
        _isFirebaseInitialized = true;
      });
      fetchCourses();
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    }
  }

  void fetchCourses() async {
    if (!_isFirebaseInitialized) return;

    try {
      final QuerySnapshot snapshot =
          await FirebaseFirestore.instance.collection('courses').get();
      setState(() {
        _courses.clear();
        _courses.addAll(snapshot.docs.map((doc) {
          return Course(
            title: doc['title'],
            description: doc['description'],
            tuitionFee: doc['tuitionFee'],
          );
        }).toList());
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    }
  }

  void addCourse() async {
    if (!_isFirebaseInitialized) return;

    try {
      final String title = _titleController.text;
      final String description = _descriptionController.text;
      final int tuitionFee = int.parse(_tuitionFeeController.text);

      await FirebaseFirestore.instance.collection('courses').add({
        'title': title,
        'description': description,
        'tuitionFee': tuitionFee,
      });

      _titleController.clear();
      _descriptionController.clear();
      _tuitionFeeController.clear();

      fetchCourses(); // Refresh the course list
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_errorMessage.isNotEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: Text(AppLocalization.of(context).translate('Error')),
        ),
        body: Center(
          child: Text(_errorMessage),
        ),
      );
    }

    if (!_isFirebaseInitialized) {
      return Scaffold(
        appBar: AppBar(
          title: Text(AppLocalization.of(context).translate('Loading')),
        ),
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalization.of(context).translate('Tuition Management')),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: AppLocalization.of(context).translate('Course Title'),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _descriptionController,
              decoration: InputDecoration(
                labelText: AppLocalization.of(context).translate('Description'),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _tuitionFeeController,
              decoration: InputDecoration(
                labelText: AppLocalization.of(context).translate('Tuition Fee'),
              ),
              keyboardType: TextInputType.number,
            ),
          ),
          ElevatedButton(
            onPressed: addCourse,
            child: Text(AppLocalization.of(context).translate('Add Course')),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _courses.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.all(8.0),
                  child: ListTile(
                    title: Text(_courses[index].title),
                    subtitle: Text(_courses[index].description),
                    trailing: Text(
                      '${AppLocalization.of(context).translate('Tuition Fee')}: \$${_courses[index].tuitionFee}',
                    ),
                    onTap: () {
                      startCourse(_courses[index], context);
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void startCourse(Course course, BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CourseDetailPage(course: course),
      ),
    );
  }
}
