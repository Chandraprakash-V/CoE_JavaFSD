import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart'; // Added for localization
import 'localization/app_localization.dart';
import 'screens/home_page.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
void main() async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
);
  runApp(TuitionManagementApp());
}

class TuitionManagementApp extends StatefulWidget {
  const TuitionManagementApp({super.key});

  @override
  _TuitionManagementAppState createState() => _TuitionManagementAppState();
}

class _TuitionManagementAppState extends State<TuitionManagementApp> {
  Locale _locale = Locale('en', '');

  void _changeLanguage(String languageCode) {
    setState(() {
      _locale = Locale(languageCode, '');
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tuition Management',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      locale: _locale,
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        AppLocalizationDelegate(), // Ensure this delegate is implemented in your project
      ],
      supportedLocales: [
        Locale('en', ''),
        Locale('es', ''),
        Locale('ta', ''),
      ],
      home: MainPage(onLanguageChange: _changeLanguage),
    );
  }
}

class MainPage extends StatefulWidget {
  final Function(String) onLanguageChange;

  const MainPage({super.key, required this.onLanguageChange});

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  String _selectedLanguage = 'en';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalization.of(context).translate('Tuition Management')),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              AppLocalization.of(context).translate('Welcome to Tuition Management'),
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              AppLocalization.of(context).translate('Select Language'),
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 10),
            DropdownButton<String>(
              value: _selectedLanguage,
              items: [
                DropdownMenuItem(
                  value: 'en',
                  child: Text(AppLocalization.of(context).translate('English')),
                ),
                DropdownMenuItem(
                  value: 'es',
                  child: Text(AppLocalization.of(context).translate('Spanish')),
                ),
                DropdownMenuItem(
                  value: 'ta',
                  child: Text(AppLocalization.of(context).translate('Tamil')),
                ),
              ],
              onChanged: (String? newValue) {
                setState(() {
                  _selectedLanguage = newValue!;
                  widget.onLanguageChange(newValue);
                });
              },
            ),
            SizedBox(height: 20),
           
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()), // Ensure HomePage is implemented
                );
              },
              child: Text(AppLocalization.of(context).translate('Go')),
            ),
          ],
        ),
      ),
    );
  }
}
