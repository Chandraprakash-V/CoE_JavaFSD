class Course {
  final String title;
  final String description;
  final double tuitionFee;

  Course({
    required this.title,
    required this.description,
    required this.tuitionFee,
  });
}
