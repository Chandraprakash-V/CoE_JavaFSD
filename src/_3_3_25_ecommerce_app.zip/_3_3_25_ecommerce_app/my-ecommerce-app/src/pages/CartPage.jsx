

import React from 'react';
import Cart from '../components/Cart';

function CartPage() {
  return (
    <div className="p-4">
      <Cart />
    </div>
  );
}

export default CartPage;