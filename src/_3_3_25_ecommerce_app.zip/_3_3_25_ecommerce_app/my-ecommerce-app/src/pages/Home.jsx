
import React from 'react';
import ProductCard from '../components/ProductCard';

function Home() {
  const products = [
    { id: 1, name: 'Product 1: shirt', price: 200 },
    { id: 2, name: 'Product 2: hat', price: 30 },
    { id: 3, name: 'Product 3: bag', price: 400 },
  ];

  return (
    <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}

export default Home;