
import React, { createContext, useReducer, useContext } from 'react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const CartContext = createContext();

const cartReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_TO_CART':
      toast.success(`${action.payload.name} added to cart!`);
      return { ...state, items: [...state.items, action.payload] };
    case 'REMOVE_FROM_CART':
      const removedItem = state.items.find((item) => item.id === action.payload);
      toast.success(`${removedItem.name} removed from cart!`);
      return {
        ...state,
        items: state.items.filter((item) => item.id !== action.payload),
      };
    default:
      return state;
  }
};

const CartProvider = ({ children }) => {
  const [state, dispatch] = useReducer(cartReducer, { items: [] });

  return (
    <CartContext.Provider value={{ state, dispatch }}>
      {children}
    </CartContext.Provider>
  );
};

const useCart = () => useContext(CartContext);

export { CartProvider, useCart };