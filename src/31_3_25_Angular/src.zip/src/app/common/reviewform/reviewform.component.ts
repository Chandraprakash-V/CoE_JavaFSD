import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-reviewform',
  templateUrl: './reviewform.component.html',
  styleUrls: ['./reviewform.component.css'] // Corrected property name
})
export class ReviewformComponent {
  reviewForm: FormGroup;
  ratings = [1, 2, 3, 4, 5];

  constructor(private fb: FormBuilder, private api: ApiService) {
    // Fixed the misplaced block after constructor
    this.reviewForm = this.fb.group({
      reviewerName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      rating: ['', Validators.required],
      comments: ['', Validators.required],
    });
  }

  onSubmitReview() {
    if (this.reviewForm.valid) {
      this.api.addReview(this.reviewForm.value).subscribe({
        next: (response: any) => {
          console.log('Review submitted successfully', response);
          alert('Review submitted successfully!');
          // Optionally reset the form or show a success message
          this.reviewForm.reset();
        },
        error: (error: any) => console.error('Error submitting review:', error) // Fixed inconsistent error logging
      });
    }
  }
}