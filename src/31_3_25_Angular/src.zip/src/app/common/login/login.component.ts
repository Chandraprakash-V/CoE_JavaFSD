import { Component } from '@angular/core';
// import { ApiService } from '../../../services/api.service';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  [x: string]: any;
  username: string = '';
  password: string = '';
  loginError: string = '';

  constructor(private api: ApiService,private  router:Router) {}

  // login() {
  //   this.api.authenticate(this.username, this.password).subscribe({
  //     next: (isAuthenticated) => {
  //       if (isAuthenticated) {
  //         alert('Login successful!');
  //         this.router.navigate(['/home'])
  //         // Redirect to a different page or perform other actions
  //       } else {
  //         this.loginError = 'Invalid username or password';
  //       }
  //     },
  //     error: (error) => {
  //       console.error('Error during authentication', error);
  //       this.loginError = 'An error occurred. Please try again later.';
  //     }
  //   });
  // }
  login(){
 
    if(this.username=="user1" && this.password
    =="password"){
  
      localStorage.setItem("username",this.username)
      window.location.reload()
      //this.router.navigate(['/home'])
  }
  else alert("Invalid Credentials")
}
}