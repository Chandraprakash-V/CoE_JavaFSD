
export interface projects{
    id:string,
    Project:string,
    AssignedTo:string,
    Deadline:string,
    image:string
}
