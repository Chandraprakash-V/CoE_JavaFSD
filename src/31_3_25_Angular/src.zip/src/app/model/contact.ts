export interface contact {
    name: string;
    city: string;
    state: string;
    address: string;
    phone: string;
    image: string;
  }