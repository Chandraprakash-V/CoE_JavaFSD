import { CanActivateFn } from '@angular/router';

export const listGuard: CanActivateFn = (route, state) => {
  //return true;
  const username = localStorage.getItem('username');
  return username?true:false;
};
