import { contact } from '../model/contact';
export const contacts:contact[] = [
    {
      "name": "Microsoft Corporation",
      "address": "One Microsoft Way, Redmond",
      "city": "Redmond",
      "state": "Washington",
      "phone": "425-882-8080",
      "image": "microsoft.jpg"
    },
    {
      "name": "Google LLC",
      "address": "1600 Amphitheatre Parkway",
      "city": "Mountain View",
      "state": "California",
      "phone": "650-253-0000",
      "image": "google.jpg"
    },
    {
      "name": "Amazon Web Services",
      "address": "410 Terry Avenue North",
      "city": "Seattle",
      "state": "Washington",
      "phone": "206-266-1000",
      "image": "aws.jpg"
    }
  ]