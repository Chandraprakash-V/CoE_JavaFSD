import { FilterSubscribedCoursesPipe } from './filter-subscribed-courses.pipe';

describe('FilterSubscribedCoursesPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterSubscribedCoursesPipe();
    expect(pipe).toBeTruthy();
  });
});
